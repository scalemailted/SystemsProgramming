#include <string.h>
#include "student.h"

struct student_info make_student(void){
   struct student_info me;

   me.id = 2222222;
   strcpy(me.name, "My Name"); /* strcpy is necessary */

   me.csci_classes[0]=2120; /* array indices always being with 0 */
   me.csci_classes[1]=2450;

   strcpy(me.reason, "All the cool kids are doing it.");

   return me;
}
